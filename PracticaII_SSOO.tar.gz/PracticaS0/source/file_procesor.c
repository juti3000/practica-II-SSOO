#include <pthread.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <time.h>
#include <stdbool.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <signal.h>
#include <limits.h>

#define DEFAULT_SIZE_FP (2 * 1024 * 1024)
#define SHM_FILE "shm_dump.txt"
#define MAX_FILENAME_LENGTH 300

struct config {
    char directorioComun[100];
    char fichConsolidados[100];
    char log[100];
    int numeroProcesos;
    int sleepMin;
    int sleepMax;
    size_t size_fp;
} config;

struct transaccion {
    char usuario[50];
    char operacion[20];
    char estado[20];
    int cantidad;
    double monto;
    struct tm fechaInicio;
    struct tm fechaFin;
};

struct usuario_data {
    int transacciones_por_hora[24];
    int retiros_por_dia;
    int errores_por_dia;
    bool operaciones[3]; // Assume 3 types of operations
    double monto_total;
};

int shm_fd;
char *shm_ptr;
size_t shm_size;

void copiarContenido(FILE *origen, FILE *destino, char numeroSucursal, int *contadorLineas, char **shm_ptr, size_t *shm_size, FILE *ficheroLog);
void copiarContenidoLOG(FILE *origen, FILE *destino, int contadorLineas, char *nombreArchivo);
void leerFicheroConfiguracion(FILE *fichero);
void procesarDirectorio(const char *directorio, FILE *ficheroConsolidados, FILE *ficheroLog, int *contadorLineas, char numeroSucursal, char **shm_ptr, size_t *shm_size);
void crearFicherosDePrueba(const char *directorio, int sucursal);
void generarContenidoAleatorio(FILE *fichero, int numRegistros);
void cargarMemoriaCompartida();
void guardarMemoriaCompartida();
void manejarSenal(int senal);
void analizarPatrones(struct transaccion *transacciones, int numTransacciones, FILE *ficheroLog);
int getOperacionIndex(const char *operacion);
bool parseFecha(const char *fecha, struct tm *fecha_tm);

struct thread_data {
    char archivo[MAX_FILENAME_LENGTH];
    FILE *ficheroConsolidados;
    FILE *ficheroLog;
    int contadorLineas;
    char numeroSucursal;
};

void* procesarArchivo(void *arg) {
    struct thread_data *data = (struct thread_data*) arg;
    FILE *ficheroDirectorio = fopen(data->archivo, "r");
    if (ficheroDirectorio == NULL) {
        printf("Error al abrir el archivo %s.\n", data->archivo);
        pthread_exit(NULL);
    }
    printf("Procesando archivo: %s\n", data->archivo);
    copiarContenido(ficheroDirectorio, data->ficheroConsolidados, data->numeroSucursal, &data->contadorLineas, &shm_ptr, &shm_size, data->ficheroLog);
    copiarContenidoLOG(ficheroDirectorio, data->ficheroLog, data->contadorLineas, data->archivo);
    fclose(ficheroDirectorio);
    pthread_exit(NULL);
}

void procesarDirectorioConHilos(const char *directorio, FILE *ficheroConsolidados, FILE *ficheroLog, int *contadorLineas, char numeroSucursal) {
    DIR* dir = opendir(directorio);
    struct dirent *archivo;
    pthread_t threads[100];  // Asumimos un máximo de 100 archivos por directorio
    struct thread_data thread_data_array[100];
    int thread_count = 0;

    if (dir == NULL) {
        printf("Error al abrir el directorio %s.\n", directorio);
        return;
    }

    while ((archivo = readdir(dir)) != NULL) {
        if (archivo->d_type == DT_REG) {
            snprintf(thread_data_array[thread_count].archivo, sizeof(thread_data_array[thread_count].archivo), "%s/%s", directorio, archivo->d_name);
            thread_data_array[thread_count].ficheroConsolidados = ficheroConsolidados;
            thread_data_array[thread_count].ficheroLog = ficheroLog;
            thread_data_array[thread_count].contadorLineas = *contadorLineas;
            thread_data_array[thread_count].numeroSucursal = numeroSucursal;
            
            pthread_create(&threads[thread_count], NULL, procesarArchivo, (void*)&thread_data_array[thread_count]);
            thread_count++;
        }
    }

    for (int i = 0; i < thread_count; ++i) {
        pthread_join(threads[i], NULL);
    }

    closedir(dir);
}

int main() {
    signal(SIGINT, manejarSenal);

    char linea[300];
    int contadorLineas = 0;
    FILE *fichero = fopen("./fp.conf", "r");
    if (fichero == NULL) {
        printf("Error al abrir el archivo de configuración.\n");
        return -1;
    }
    leerFicheroConfiguracion(fichero);
    fclose(fichero);

    char *dirConsolidado = strdup(config.fichConsolidados);
    char *lastSlash = strrchr(dirConsolidado, '/');
    if (lastSlash != NULL) {
        *lastSlash = '\0';
        mkdir(dirConsolidado, 0755);  // Crear directorio si no existe
    }
    free(dirConsolidado);

    FILE *ficheroConsolidados = fopen(config.fichConsolidados, "w");
    if (ficheroConsolidados == NULL) {
        printf("Error al abrir el archivo de consolidados: %s\n", config.fichConsolidados);
        return -1;
    }

    FILE *ficheroLog = fopen(config.log, "a");
    if (ficheroLog == NULL) {
        printf("Error al abrir el archivo de log: %s\n", config.log);
        fclose(ficheroConsolidados);
        return -1;
    }

    shm_fd = shm_open("/shm_consolidado", O_CREAT | O_RDWR, 0666);
    if (shm_fd == -1) {
        printf("Error al crear la memoria compartida.\n");
        return -1;
    }
    ftruncate(shm_fd, config.size_fp);
    shm_ptr = mmap(0, config.size_fp, PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd, 0);
    if (shm_ptr == MAP_FAILED) {
        printf("Error al mapear la memoria compartida.\n");
        return -1;
    }
    shm_size = config.size_fp;

    cargarMemoriaCompartida();

    for (int i = 1; i <= 4; ++i) {
        char directorio[150];
        snprintf(directorio, sizeof(directorio), "%s/sucursal%d/", config.directorioComun, i);
        printf("Creando ficheros de prueba en el directorio: %s\n", directorio);
        crearFicherosDePrueba(directorio, i);
        printf("Procesando directorio con hilos: %s\n", directorio);
        procesarDirectorioConHilos(directorio, ficheroConsolidados, ficheroLog, &contadorLineas, '0' + i);
    }

    fclose(ficheroConsolidados);
    fclose(ficheroLog);
    guardarMemoriaCompartida();
    shm_unlink("/shm_consolidado");

    return 0;
}

void crearFicherosDePrueba(const char *directorio, int sucursal) {
    time_t t = time(NULL);
    struct tm tm = *localtime(&t);
    char fecha[9];
    strftime(fecha, sizeof(fecha), "%d%m%Y", &tm);

    char nombreArchivo1[MAX_FILENAME_LENGTH];
    char nombreArchivo2[MAX_FILENAME_LENGTH];
    snprintf(nombreArchivo1, sizeof(nombreArchivo1), "%sSU%03d_OPE%03d_%s_1.data", directorio, sucursal, sucursal, fecha);
    snprintf(nombreArchivo2, sizeof(nombreArchivo2), "%sSU%03d_OPE%03d_%s_2.data", directorio, sucursal, sucursal, fecha);

    FILE *fichero1 = fopen(nombreArchivo1, "w");
    FILE *fichero2 = fopen(nombreArchivo2, "w");

    if (fichero1 == NULL || fichero2 == NULL) {
        printf("Error al crear los ficheros de prueba.\n");
        if (fichero1) fclose(fichero1);
        if (fichero2) fclose(fichero2);
        return;
    }

    generarContenidoAleatorio(fichero1, 10);
    generarContenidoAleatorio(fichero2, 10);

    fclose(fichero1);
    fclose(fichero2);
}

void generarContenidoAleatorio(FILE *fichero, int numRegistros) {
    const char *operaciones[] = {"COMPRA01", "COMPRA02", "RETIRO01"};
    const char *usuarios[] = {"USER001", "USER002", "USER003"};
    const char *estados[] = {"Error", "Finalizado", "Correcto"};
    int numOperaciones = sizeof(operaciones) / sizeof(operaciones[0]);
    int numUsuarios = sizeof(usuarios) / sizeof(usuarios[0]);
    int numEstados = sizeof(estados) / sizeof(estados[0]);

    for (int i = 0; i < numRegistros; ++i) {
        int opIndex = rand() % numOperaciones;
        int userIndex = rand() % numUsuarios;
        int estadoIndex = rand() % numEstados;

        int dia = rand() % 28 + 1;
        int mes = rand() % 12 + 1;
        int anio = 2024;
        int hora = rand() % 24;
        int minuto = rand() % 60;

        char fechaInicio[20], fechaFin[20];
        snprintf(fechaInicio, sizeof(fechaInicio), "%02d/%02d/%04d %02d:%02d", dia, mes, anio, hora, minuto);
        snprintf(fechaFin, sizeof(fechaFin), "%02d/%02d/%04d %02d:%02d", dia, mes, anio, hora, minuto + (rand() % 60));

        fprintf(fichero, "OPE%03d;%s;%s;%s;%s;%d;%+.1f;%s\n",
                rand() % 1000,
                fechaInicio,
                fechaFin,
                usuarios[userIndex],
                operaciones[opIndex],
                rand() % 10 + 1,
                (rand() % 2001 - 1000) / 10.0,
                estados[estadoIndex]);
    }
}

void copiarContenidoLOG(FILE *origen, FILE *destino, int contadorLineas, char *nombreArchivo) {
    time_t rawtime;
    struct tm fechaHoraActual;
    char fechaHora[80];

    time(&rawtime);
    fechaHoraActual = *localtime(&rawtime);

    fprintf(destino, "%d:%d:%d:::%d:::%s\n", fechaHoraActual.tm_hour, fechaHoraActual.tm_min, fechaHoraActual.tm_sec, contadorLineas, nombreArchivo);
}

void copiarContenido(FILE *origen, FILE *destino, char numeroSucursal, int *contadorLineas, char **shm_ptr, size_t *shm_size, FILE *ficheroLog) {
    char linea[300];
    struct transaccion transacciones[1000];
    int numTransacciones = 0;
    *contadorLineas = 0;

    while (fgets(linea, sizeof(linea), origen)) {
        fprintf(destino, "%c;%s", numeroSucursal, linea);

        size_t linea_len = strlen(linea) + 3;
        if (strlen(*shm_ptr) + linea_len >= *shm_size) {
            *shm_size *= 2;
            if (ftruncate(shm_fd, *shm_size) == -1) {
                printf("Error al redimensionar la memoria compartida.\n");
                return;
            }
            munmap(*shm_ptr, *shm_size / 2);
            *shm_ptr = mmap(0, *shm_size, PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd, 0);
            if (*shm_ptr == MAP_FAILED) {
                printf("Error al remapear la memoria compartida.\n");
                return;
            }
        }
        snprintf(*shm_ptr + strlen(*shm_ptr), *shm_size - strlen(*shm_ptr), "%c;%s", numeroSucursal, linea);

        struct transaccion t;
        char fechaInicio[20], fechaFin[20];
        sscanf(linea, "OPE%*d;%[^;];%[^;];%[^;];%[^;];%d;%lf;%[^;\n]",
               fechaInicio, fechaFin, t.usuario, t.operacion, &t.cantidad, &t.monto, t.estado);

        if (!parseFecha(fechaInicio, &t.fechaInicio) || !parseFecha(fechaFin, &t.fechaFin)) {
            printf("Error al analizar la fecha\n");
            continue;
        }

        transacciones[numTransacciones++] = t;
        (*contadorLineas)++;
    }

    fprintf(destino, "\n");
    analizarPatrones(transacciones, numTransacciones, ficheroLog);
}

bool parseFecha(const char *fecha, struct tm *fecha_tm) {
    return sscanf(fecha, "%d/%d/%d %d:%d",
                  &fecha_tm->tm_mday,
                  &fecha_tm->tm_mon,
                  &fecha_tm->tm_year,
                  &fecha_tm->tm_hour,
                  &fecha_tm->tm_min) == 5;
}

void leerFicheroConfiguracion(FILE *fichero) {
    char linea[300];

    while (fgets(linea, sizeof(linea), fichero)) {
        char *token = strtok(linea, "=");
        token[strcspn(token, "\n")] = '\0';

        if (strcmp(token, "DIRECTORIOCOMUN") == 0) {
            token = strtok(NULL, "=");
            token[strcspn(token, "\n")] = '\0';
            strcpy(config.directorioComun, token);
        } else if (strcmp(token, "FICHCONSOLIDADOS") == 0) {
            token = strtok(NULL, "=");
            token[strcspn(token, "\n")] = '\0';
            strcpy(config.fichConsolidados, token);
        } else if (strcmp(token, "LOG") == 0) {
            token = strtok(NULL, "=");
            token[strcspn(token, "\n")] = '\0';
            strcpy(config.log, token);
        } else if (strcmp(token, "NUMERO_PROCESOS") == 0) {
            token = strtok(NULL, "=");
            token[strcspn(token, "\n")] = '\0';
            config.numeroProcesos = atoi(token);
        } else if (strcmp(token, "SLEEP_MINIMO") == 0) {
            token = strtok(NULL, "=");
            token[strcspn(token, "\n")] = '\0';
            config.sleepMin = atoi(token);
        } else if (strcmp(token, "SLEEP_MAXIMO") == 0) {
            token = strtok(NULL, "=");
            token[strcspn(token, "\n")] = '\0';
            config.sleepMax = atoi(token);
        } else if (strcmp(token, "SIZE_FP") == 0) {
            token = strtok(NULL, "=");
            token[strcspn(token, "\n")] = '\0';
            config.size_fp = atoi(token);
        }
    }

    if (config.size_fp == 0) {
        config.size_fp = DEFAULT_SIZE_FP;
    }
}

void cargarMemoriaCompartida() {
    FILE *shm_file = fopen(SHM_FILE, "r");
    if (shm_file) {
        fseek(shm_file, 0, SEEK_END);
        long file_size = ftell(shm_file);
        fseek(shm_file, 0, SEEK_SET);

        if (file_size > shm_size) {
            ftruncate(shm_fd, file_size);
            munmap(shm_ptr, shm_size);
            shm_size = file_size;
            shm_ptr = mmap(0, shm_size, PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd, 0);
            if (shm_ptr == MAP_FAILED) {
                printf("Error al remapear la memoria compartida.\n");
                fclose(shm_file);
                return;
            }
        }

        fread(shm_ptr, 1, file_size, shm_file);
        fclose(shm_file);
    }
}

void guardarMemoriaCompartida() {
    FILE *shm_file = fopen(SHM_FILE, "w");
    if (shm_file) {
        fwrite(shm_ptr, 1, strlen(shm_ptr), shm_file);
        fclose(shm_file);
    }
}

void manejarSenal(int senal) {
    if (senal == SIGINT) {
        printf("\nInterrupción recibida, guardando la memoria compartida en fichero...\n");
        guardarMemoriaCompartida();
        shm_unlink("/shm_consolidado");
        exit(0);
    }
}

void analizarPatrones(struct transaccion *transacciones, int numTransacciones, FILE *ficheroLog) {
    char usuarios[100][50];
    struct usuario_data usuarioDatos[100] = {0};
    int numUsuarios = 0;

    for (int i = 0; i < numTransacciones; i++) {
        struct transaccion *t = &transacciones[i];
        int usuarioIndex = -1;
        for (int j = 0; j < numUsuarios; j++) {
            if (strcmp(usuarios[j], t->usuario) == 0) {
                usuarioIndex = j;
                break;
            }
        }
        if (usuarioIndex == -1) {
            strcpy(usuarios[numUsuarios], t->usuario);
            usuarioIndex = numUsuarios++;
        }

        struct usuario_data *ud = &usuarioDatos[usuarioIndex];
        int hora = t->fechaInicio.tm_hour;
        int dia = t->fechaInicio.tm_mday;

        ud->transacciones_por_hora[hora]++;
        if (strstr(t->operacion, "RETIRO") != NULL) {
            ud->retiros_por_dia++;
        }
        if (strcmp(t->estado, "Error") == 0) {
            ud->errores_por_dia++;
        }
        int opIndex = getOperacionIndex(t->operacion);
        if (opIndex != -1) {
            ud->operaciones[opIndex] = true;
        }
        if (t->monto < 0) {
            ud->monto_total += t->monto;
        }

        if (ud->transacciones_por_hora[hora] > 5) {
            fprintf(ficheroLog, "Patrón 1 detectado: Más de 5 transacciones en una hora para el usuario %s.\n", t->usuario);
        }
        if (ud->retiros_por_dia > 3) {
            fprintf(ficheroLog, "Patrón 2 detectado: Más de 3 retiros en un día para el usuario %s.\n", t->usuario);
        }
        if (ud->errores_por_dia > 3) {
            fprintf(ficheroLog, "Patrón 3 detectado: Más de 3 errores en un día para el usuario %s.\n", t->usuario);
        }
        if (ud->operaciones[0] && ud->operaciones[1] && ud->operaciones[2]) {
            fprintf(ficheroLog, "Patrón 4 detectado: Operación de cada tipo en un día para el usuario %s.\n", t->usuario);
        }
        if (ud->monto_total < -100) { // Actualizar condición según sea necesario
            fprintf(ficheroLog, "Patrón 5 detectado: Cantidad retirada mayor que la ingresada para el usuario %s.\n", t->usuario);
        }
    }
}

int getOperacionIndex(const char *operacion) {
    if (strcmp(operacion, "COMPRA01") == 0) return 0;
    if (strcmp(operacion, "COMPRA02") == 0) return 1;
    if (strcmp(operacion, "RETIRO01") == 0) return 2;
    return -1;
}
