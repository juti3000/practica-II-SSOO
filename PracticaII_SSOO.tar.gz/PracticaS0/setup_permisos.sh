#!/bin/bash

# Crear grupos si no existen
if ! getent group ufvauditor > /dev/null; then
    groupadd ufvauditor
fi

if ! getent group ufvusuarios > /dev/null; then
    groupadd ufvusuarios
fi

# Crear usuarios para cada sucursal y añadirlos al grupo ufvauditor si no existen
if ! id -u userSU001 > /dev/null 2>&1; then
    useradd -m -G ufvauditor -s /bin/bash userSU001
fi

if ! id -u userSU002 > /dev/null 2>&1; then
    useradd -m -G ufvauditor -s /bin/bash userSU002
fi

if ! id -u userSU003 > /dev/null 2>&1; then
    useradd -m -G ufvauditor -s /bin/bash userSU003
fi

if ! id -u userSU004 > /dev/null 2>&1; then
    useradd -m -G ufvauditor -s /bin/bash userSU004
fi

# Crear usuarios userfp y usermonitor y añadirlos al grupo ufvusuarios si no existen
if ! id -u userfp > /dev/null 2>&1; then
    useradd -m -G ufvusuarios -s /bin/bash userfp
fi

if ! id -u usermonitor > /dev/null 2>&1; then
    useradd -m -G ufvusuarios -s /bin/bash usermonitor
fi

# Crear directorios y establecer permisos
mkdir -p files_data/sucursal1
mkdir -p files_data/sucursal2
mkdir -p files_data/sucursal3
mkdir -p files_data/sucursal4

chown userSU001:ufvauditor files_data/sucursal1
chown userSU002:ufvauditor files_data/sucursal2
chown userSU003:ufvauditor files_data/sucursal3
chown userSU004:ufvauditor files_data/sucursal4

chmod 750 files_data/sucursal1
chmod 750 files_data/sucursal2
chmod 750 files_data/sucursal3
chmod 750 files_data/sucursal4

# Configurar permisos para los archivos de prueba si existen
if [ -d "files_data/sucursal1" ]; then
    if compgen -G "files_data/sucursal1/*" > /dev/null; then
        chown userSU001:ufvauditor files_data/sucursal1/*
        chmod 640 files_data/sucursal1/*
    fi
fi

if [ -d "files_data/sucursal2" ]; then
    if compgen -G "files_data/sucursal2/*" > /dev/null; then
        chown userSU002:ufvauditor files_data/sucursal2/*
        chmod 640 files_data/sucursal2/*
    fi
fi

if [ -d "files_data/sucursal3" ]; then
    if compgen -G "files_data/sucursal3/*" > /dev/null; then
        chown userSU003:ufvauditor files_data/sucursal3/*
        chmod 640 files_data/sucursal3/*
    fi
fi

if [ -d "files_data/sucursal4" ]; then
    if compgen -G "files_data/sucursal4/*" > /dev/null; then
        chown userSU004:ufvauditor files_data/sucursal4/*
        chmod 640 files_data/sucursal4/*
    fi
fi

# Permisos para los ejecutables si existen
if [ -f "source/file_procesor" ]; then
    chmod 750 source/file_procesor
    chown userfp:ufvusuarios source/file_procesor
fi

if [ -f "source/file_monitor" ]; then
    chmod 750 source/file_monitor
    chown usermonitor:ufvusuarios source/file_monitor
fi

# Permisos para el archivo de configuración si existe
if [ -f "conf/fp.conf" ]; then
    chmod 660 conf/fp.conf
    chown userfp:ufvusuarios conf/fp.conf
fi

# Permisos para los logs
mkdir -p log
touch log/file.log
chmod 660 log/file.log
chown userfp:ufvusuarios log/file.log
